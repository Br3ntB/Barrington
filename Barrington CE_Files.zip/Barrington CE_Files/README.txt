CE Files for Barrington are the work of xx_JARETH_xx.  He has done an amazing job at working out the layout.
All credit goes to him. 

!!! TRY OUT THE LABYRINTH" DayZ servers !!!  xx_JARETH_xx has done a great job with Barrington.